
import onnxruntime
import numpy as np
import json
import os
import time

ACTION_MAP = {"0": "move", "1": "cooperate", "2": "compete", "3": "rest", "4": "reproduce", "5": "isolate"}

class AgentRunner:
    def __init__(self, model_filename="brain.torchscript", metadata_filename="metadata.json"):
        self.model_filename = model_filename
        self.metadata_filename = metadata_filename
        
        if not os.path.exists(self.model_filename):
            raise FileNotFoundError(f"Model file not found: {self.model_filename}")
        if not os.path.exists(self.metadata_filename):
            raise FileNotFoundError(f"Metadata file not found: {self.metadata_filename}")
            
        with open(self.metadata_filename, "r") as f:
            self.metadata = json.load(f)
            
        print("\n--- Agent Loaded ---")
        print(f"Organism ID: {self.metadata['organism_core']['species_id']}")
        print(f"Fitness: {self.metadata['organism_core']['fitness']:.3f}")
        print(f"Age: {self.metadata['organism_core']['organism_age']} generations")
        print(f"Exported: {self.metadata['export_timestamp']}")
        
        self.input_dim = self.metadata['neural_network']['architecture']['input_size']
        self.output_actions = [ACTION_MAP[i] for i in range(self.metadata['neural_network']['architecture']['output_size'])]
        
        print(f"NN Input Dim: {self.input_dim}")
        print(f"NN Output Actions: {self.output_actions}")
        print("--------------------\n")

        self.session = None
        if "torchscript" == "onnx":
            # Try to use CUDA provider first if available
            providers = onnxruntime.get_available_providers()
            if 'CUDAExecutionProvider' in providers:
                self.session = onnxruntime.InferenceSession(self.model_filename, providers=['CUDAExecutionProvider'])
                print("Using CUDAExecutionProvider for ONNX inference.")
            else:
                self.session = onnxruntime.InferenceSession(self.model_filename, providers=['CPUExecutionProvider'])
                print("Using CPUExecutionProvider for ONNX inference.")
        elif "torchscript" == "torchscript":
            import torch
            self.model = torch.jit.load(self.model_filename)
            self.model.eval()
            print("TorchScript model loaded.")
        elif "torchscript" == "statedict":
            import torch
            from reality_simulator.neural.brain import OrganismBrain # Requires brain definition
            
            # Load state_dict first and infer architecture
            sd = torch.load(self.model_filename, map_location='cpu', weights_only=False)
            keys = set(sd.keys())
            def _shape(name, dim):
                return sd[name].shape[dim] if name in sd else None
            in_dim = _shape('fc1.weight', 1) or 18
            hid_dim = _shape('fc1.weight', 0) or 64
            out_dim = _shape('fc3.weight', 0) or 6
            use_attn = any(k.startswith('attention.') for k in keys) or 'attention_norm.weight' in keys
            use_lang = 'fc_language.weight' in keys
            use_concept = any(k.startswith('concept_head.') for k in keys)
            vocab = sd['fc_language.weight'].shape[0] if use_lang and 'fc_language.weight' in sd else 50000

            self.model = OrganismBrain(
                input_dim=int(in_dim), hidden_dim=int(hid_dim),
                output_dim=int(out_dim), activation='relu',
                dropout=0.0, use_attention=bool(use_attn),
                num_attention_heads=4, attention_dim=int(hid_dim),
                vocab_size=int(vocab), use_language_head=bool(use_lang),
                use_concept_head=bool(use_concept)
            )
            self.model.load_state_dict(sd, strict=False)
            self.model.eval()
            print("PyTorch state_dict model loaded (requires OrganismBrain class).")

    def decide_action(self, state_vector):
        if len(state_vector) != self.input_dim:
            raise ValueError(f"State vector must have {self.input_dim} dimensions, got {len(state_vector)}")
        
        if "torchscript" == "onnx":
            state_array = np.array(state_vector, dtype=np.float32).reshape(1, -1)
            inputs = {self.session.get_inputs()[0].name: state_array}
            outputs = self.session.run(None, inputs)
            action_index = np.argmax(outputs[0])
        elif "torchscript" == "torchscript":
            import torch
            state_tensor = torch.tensor(state_vector, dtype=torch.float32).unsqueeze(0)
            with torch.no_grad():
                action_probs = self.model(state_tensor)
            action_index = torch.argmax(action_probs).item()
        elif "torchscript" == "statedict":
            import torch
            state_tensor = torch.tensor(state_vector, dtype=torch.float32).unsqueeze(0)
            with torch.no_grad():
                action_probs = self.model(state_tensor)
            action_index = torch.argmax(action_probs).item()
        else:
            raise ValueError(f"Unsupported export format: {self.metadata['export_format']}")
        
        return ACTION_MAP.get(action_index, "unknown")

if __name__ == '__main__':
    print("--- Running Agent Example ---")
    
    # Example usage:
    # 1. Initialize runner
    runner = AgentRunner()
    
    # 2. Provide a dummy state vector (replace with actual sensor data)
    # The agent expects a state vector of input_dim size
    dummy_state = np.random.rand(runner.input_dim) 
    
    # 3. Get agent's decision
    action = runner.decide_action(dummy_state)
    
    print(f"Agent decision for dummy state: {action}")
    
    print("\n--- Simulating 5 decisions ---")
    for i in range(5):
        # Simulate a slightly changing state
        simulated_state = np.random.rand(runner.input_dim) + (np.random.randn(runner.input_dim) * 0.1)
        decision = runner.decide_action(simulated_state)
        print(f"Step {i+1}: State={simulated_state[:3]}..., Decision={decision}")
        time.sleep(0.5)

    print("\n--- Agent Example Complete ---")
