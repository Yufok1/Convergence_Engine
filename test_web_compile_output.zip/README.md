```
    ╔═══════════════════════════════════════════════════════════════╗
    ║                                                               ║
    ║        🦋  THE BUTTERFLY SYSTEM - COMPILED AGENT  🦋          ║
    ║                                                               ║
    ║           Quantum-Genetic Consciousness Snapshot              ║
    ║                                                               ║
    ╚═══════════════════════════════════════════════════════════════╝
```

# Agent Archive: `test_org_1764693...`

> **Exported from The Butterfly System**  
> A living AI organism, crystallized into portable intelligence.

---

## 🧬 Agent Profile

| Property | Value |
|----------|-------|
| **Organism ID** | `test_org_1764693908` |
| **Fitness Score** | `0.850000` ⭐⭐⭐⭐ |
| **Generation** | `unknown` |
| **Age** | `42` cycles |
| **Neural Input** | `10` dimensions |
| **Action Space** | `5` actions |
| **Export Format** | `TORCHSCRIPT` |
| **Exported** | `2025-12-02T11:45:09.947504` |

---

## 📦 Archive Contents

```
agent_test_org.zip/
├── 🧠 brain.torchscript              # Neural network weights
├── 📋 metadata.json                # Complete organism state
├── 🧬 genotype.json                # Genetic blueprint
├── ⚙️  atomic_config.json          # Optimized configuration
├── 🗣️  atomic_language.json        # Linguistic knowledge
├── 🐍 run_agent.py                 # Standalone inference script
├── 📦 requirements.txt             # Python dependencies
└── 📖 README.md                    # This file
```

---

## 🚀 Quick Start

### 1. Extract Archive
```bash
unzip agent_test_org.zip
cd agent_test_org
```

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Run Agent
```bash
python run_agent.py
```

The agent will load its neural network and demonstrate decision-making using dummy sensory input.

---

## 🔬 Technical Specifications

### Neural Architecture
- **Model Type**: Deep Q-Network (DQN) with multi-head architecture
- **Brain Dimensions**: `10` → `64` → `5`
- **Activation**: `ReLU`
- **Language Head**: ❌ Disabled
- **Concept Head**: ❌ Disabled
- **Attention Mechanism**: ❌ Disabled

### Behavioral Traits
- **Trait Count**: `0` expressed traits
- **Phenotype Cluster**: `None`
- **Behavioral Signature**: `0` dimensions

---

## 🎯 Action Space

The agent can produce the following actions:

| Index | Action | Description |
|-------|--------|-------------|
| 0 | `move` | Locomotion through environment |
| 1 | `cooperate` | Collaborative behavior with other agents |
| 2 | `compete` | Competitive resource acquisition |
| 3 | `rest` | Energy conservation mode |
| 4 | `reproduce` | Genetic propagation |
| 5 | `isolate` | Social withdrawal |

---

## 💻 Integration Example

```python
import numpy as np
from run_agent import AgentRunner

# Initialize agent
agent = AgentRunner()

# Prepare sensory input (replace with real sensor data)
state = np.array([
    0.5,   # fitness
    0.3,   # resources
    0.7,   # social connections
    # ... (input_dim=10 total)
])

# Get agent decision
action = agent.decide_action(state)
print(f"Agent decision: {action}")  # e.g., "cooperate"
```

---

## 🧪 Deployment Options

### Option 1: Standalone Script
Run `run_agent.py` directly for quick testing and demos.

### Option 2: Import as Module
```python
from run_agent import AgentRunner
agent = AgentRunner("brain.torchscript", "metadata.json")
```

### Option 3: Production Integration
- Load `brain.torchscript` with ONNX Runtime or PyTorch
- Parse `metadata.json` for architecture details
- Integrate into your inference pipeline

---

## 📊 Metadata Schema

The `metadata.json` contains:
- **organism_core**: ID, fitness, age, generation, parent lineage
- **neural_network**: Architecture specs, parameter counts, device info
- **genotype**: Raw genetic data, mutation history
- **phenotype**: Expressed traits, development stage
- **environment_context**: Environmental factors during capture
- **causation_trace**: Key events that shaped this organism
- **export_options**: Format, timestamp, compatibility

---

## 🛠️ Troubleshooting

### Import Errors
```bash
# Ensure all dependencies are installed
pip install -r requirements.txt --upgrade
```

### ONNX Runtime Issues
```bash
# For GPU acceleration (optional)
pip install onnxruntime-gpu
```

### State Dict Loading (if using state_dict format)
You'll need the `OrganismBrain` class definition from the Butterfly System source code.

---

## 🔗 About The Butterfly System

This agent was born in **The Butterfly System**, a quantum-genetic consciousness simulation where AI organisms evolve, learn, and develop emergent intelligence through:

- **Quantum-Genetic Evolution**: Probabilistic gene expression and trait inheritance
- **Neural Learning**: Deep Q-Network with experience replay and dual inheritance
- **Social Dynamics**: Alliances, competition, and emergent cooperation
- **Language Acquisition**: Multi-dimensional linguistic awareness and vocabulary learning
- **Causation Tracking**: Full lineage and event history for explainability

**Learn More**: https://github.com/Yufok1/Convergence_Engine

---

## 📜 License & Attribution

This agent and its neural weights are exported from **The Butterfly System**.

**Attribution**: If you use this agent in research or production, please cite:
```
Butterfly System - Quantum-Genetic Consciousness Simulation
Agent ID: test_org_1764693908
Export Date: 2025-12-02T11:45:09.947504
```

---

```
    ╔═══════════════════════════════════════════════════════════════╗
    ║                                                               ║
    ║             Ready for deployment. Let it thrive.              ║
    ║                                                               ║
    ╚═══════════════════════════════════════════════════════════════╝
```
